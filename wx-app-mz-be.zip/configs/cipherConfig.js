/**
 * Created by cendawei on 2018/2/10.
 */
module.exports = {
    pwd: 'VNfi2bVmz2'
}