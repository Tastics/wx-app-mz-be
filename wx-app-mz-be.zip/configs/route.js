/**
 * Created by cendawei on 2018/1/26.
 */
module.exports = {
    routePrefix: '/wx/mz'
}