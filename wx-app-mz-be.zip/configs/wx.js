/**
 * Created by cendawei on 2018/2/5.
 */
module.exports = {
    token: 'cdroomwxmz'
}