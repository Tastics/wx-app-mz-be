define(function () {
	return jQuery;
});
