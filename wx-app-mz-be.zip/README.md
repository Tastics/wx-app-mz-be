### CDroom码字后台功能点：
- 将文本内容生成二维码
- 生成的二维码文本支持单页面多场景选择
- 二维码内容加密，只能通过本码字系统解密输出
- 实现二维码有效时间控制，超过预设的有效期时间，二维码自动失效
- 安全可靠，又生动有趣的码字平台
### 技术架构
> 微信小程序（CDroom码字）+ 码字后台（本github项目）
### 手机扫码预览demo：
![](http://app.cdroom.top/wx/mz/webroot/images/wx-mz.png)
### `项目合作联系：business@cdroom.top`
